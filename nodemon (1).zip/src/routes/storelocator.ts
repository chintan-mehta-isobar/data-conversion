import { injectable } from "inversify";
import { iocContainer } from "../ioc-container";
import { Router, Request, Response, NextFunction } from 'express';
import { StoreLocatorController } from '../controller/storelocator.controller';
@injectable()

export class StoreLocatorRouter {

    router: Router
    constructor() {
        this.router = Router();
        this.init();
    }

    public generateReport(req: Request, res: Response, next: NextFunction) {
        const storeLocatorController = iocContainer.get<StoreLocatorController>(StoreLocatorController);
        storeLocatorController.generateStoreLocatorXml(req, res);
    }

    init() {
        this.router.get('/', this.generateReport);
    }
};

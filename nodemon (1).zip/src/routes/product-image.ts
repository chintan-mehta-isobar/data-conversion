import { injectable } from "inversify";
import { iocContainer } from "../ioc-container";
import { Router, Request, Response, NextFunction } from 'express';
import { ProductImageController } from '../controller/product-image.controller';
@injectable()

export class ProductImageRouter {

    router: Router
    constructor() {
        this.router = Router();
        this.init();
    }

    public generateProductImageMapping(req: Request, res: Response, next: NextFunction) {
        const productImageController = iocContainer.get<ProductImageController>(ProductImageController);
        productImageController.generateImageMapping(req, res);
    }

    init() {
        this.router.get('/', this.generateProductImageMapping);
    }
};

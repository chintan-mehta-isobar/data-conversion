import { injectable } from "inversify";
import { iocContainer } from "../ioc-container";
import { Router, Request, Response, NextFunction } from 'express';
import { VariantController }   from '../controller/variant.controller';
@injectable()

export class UserRouter {

    router: Router
    constructor() {
        this.router = Router();
        this.init();
    }

    public getAll(req:Request, res: Response, next: NextFunction){
        const userController = iocContainer.get<VariantController>(VariantController);
        userController.validateUserCredentials(req, res);
    }

    init(){
        this.router.get('/', this.getAll);
    }
};

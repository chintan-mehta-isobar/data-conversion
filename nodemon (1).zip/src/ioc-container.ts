import 'reflect-metadata';
import { Container } from "inversify";
import { UserRouter } from './routes/user';
import { ProductImageRouter } from './routes/product-image';
import { StoreLocatorRouter } from './routes/storelocator';

import { VariantController } from './controller/variant.controller';
import { ProductImageController } from './controller/product-image.controller';
import { StoreLocatorController } from './controller/storelocator.controller';

import { UserService } from './services/user.service';
import { UserRepository } from './repositories/user.repository';
import { App } from './app';

const iocContainer = new Container();

iocContainer.bind<App>(App).to(App);
iocContainer.bind<UserRouter>(UserRouter).to(UserRouter);
iocContainer.bind<ProductImageRouter>(ProductImageRouter).to(ProductImageRouter);
iocContainer.bind<StoreLocatorRouter>(StoreLocatorRouter).to(StoreLocatorRouter);

iocContainer.bind<VariantController>(VariantController).to(VariantController);
iocContainer.bind<ProductImageController>(ProductImageController).to(ProductImageController);
iocContainer.bind<StoreLocatorController>(StoreLocatorController).to(StoreLocatorController);

iocContainer.bind<UserService>(UserService).to(UserService);
iocContainer.bind<UserRepository>(UserRepository).to(UserRepository);

export { iocContainer };
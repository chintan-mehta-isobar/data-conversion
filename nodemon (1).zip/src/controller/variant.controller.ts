import { injectable } from "inversify";
import { Request, Response } from 'express';
const builder = require('xmlbuilder');
const variation = require('./json/firefox_variation_data.json');
@injectable()

export class VariantController {
    constructor() { }

    async validateUserCredentials(req: Request, res: Response) {

        const variantsData = [] as any;
        const requiredDataObject = new Promise((resolve, reject) => {
            variation.map((data: any) => {
                const variantObject = {} as any;
                if (data.variants !== "") {
                    variantObject.productId = data.ID;
                    variantObject.attributes = [];

                    let attribute = {
                        frameSize: {},
                        colors: {}
                    } as any;


                    const frameSizeData = this.getframeSizes(data.variants).then((frameSize: any) => {
                        attribute.frameSize.name = 'Frame Size';
                        attribute.frameSize.attributeId = 'frameSize';
                        attribute.frameSize.variationAttributeId = 'size';
                        attribute.frameSize.values = frameSize;
                        return;
                    });

                    const colorsData = this.getVariantColors(data.variants).then((colors: any) => {
                        attribute.colors.name = 'Color';
                        attribute.colors.attributeId = 'color';
                        attribute.colors.variationAttributeId = 'color';
                        attribute.colors.values = colors;
                        return;
                    });

                    // const imageData = this.getVariantImages(data.variants).then((colors: any) => {
                    //     console.log(colors);
                    //     attribute.colors.name = 'Image';
                    //     attribute.colors.attributeId = 'color';
                    //     attribute.colors.variationAttributeId = 'color';
                    //     attribute.colors.values = colors;
                    //     return;
                    // });

                    // frameSizeData, colorsData,
                    return Promise.all([frameSizeData, colorsData]).then(() => {
                        variantObject.attributes.push(attribute);
                        variantsData.push(variantObject);
                        return resolve(variantObject);
                    });

                    // For lectro as have just one variant 
                    // return Promise.all([colorsData]).then(() => {
                    //     variantObject.attributes.push(attribute);
                    //     variantsData.push(variantObject);
                    //     return resolve(variantObject);
                    // });


                } else {
                    return null;
                }
            });
        });

        return requiredDataObject.then(async () => {
            res.set('Content-Type', 'text/xml');
            const responseData = await this.generateXML(variantsData);
            return res.send(responseData);
            // return res.json(variantsData);
        });
    }

    private generateXML(productVariantData: any) {
        return this.mapProductVariantAttributes(productVariantData).then((productAttributes) => {
            const obj = {
                catalog: {
                    '@xmlns': 'http://www.demandware.com/xml/impex/catalog/2006-10-31',
                    '@catalog-id': 'lectro-master',
                    product: productAttributes
                }
            };
            const feed = builder.create(obj, { encoding: 'UTF-8' })
            return feed.end({ pretty: true });
        })
    }

    private async mapProductVariantAttributes(productVariantData: any) {
        let variationAttrData = [] as any;
        const dataVariant = new Promise((resolve, reject) => {
            productVariantData.map(async (val: any) => {
                let variationAttrValues = {
                    '@product-id': val.productId,
                    variations: {
                        attributes: await this.mapVariationsAttributes(val.attributes),
                        // variants: this.mapProductVariants(),
                    }
                }
                variationAttrData.push(variationAttrValues)
                resolve(variationAttrData);
            });
        });

        return dataVariant.then(() => {
            return variationAttrData;
        });
    }

    private async mapVariationsAttributes(attributes: any) {
        let attributesMappingData = [] as any;
        const dataVariant = new Promise((resolve, reject) => {
            attributes.map(async (val: any) => {
                let attributesMapping = {
                    "variation-attribute": await this.mapAttributes(val)
                }
                attributesMappingData.push(attributesMapping);
                resolve(attributesMappingData)
            });
        });

        return dataVariant.then(() => {
            return attributesMappingData;
        });
    }

    private async mapAttributes(variationAttibutes: any) {
        const variationAttibuteData = [] as any;
        const dataVariant = new Promise((resolve, reject) => {
            Object.keys(variationAttibutes).map(async (val: any) => {
                let variationAttibuteValues;
                variationAttibuteValues = {
                    '@attribute-id': variationAttibutes[val].attributeId,
                    '@variation-attribute-id': variationAttibutes[val].variationAttributeId,
                    'display-name': {
                        '@xml:lang': 'x-default',
                        '#text': variationAttibutes[val].name,
                    },
                    'variation-attribute-values': await this.mapAttributeValues(variationAttibutes[val].values)
                };

                console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                console.log(variationAttibuteValues);
                console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                variationAttibuteData.push(variationAttibuteValues);
                resolve(variationAttibuteData);
            });
        });
        return dataVariant.then(() => {
            return variationAttibuteData;
        });
    }

    private async mapAttributeValues(variantsData: any) {
        const variatValues = [] as any;
        await variantsData.map(async (val: any) => {
            let attributeValues = {
                '@value': val.split(" ").join(''),
                'display-value': {
                    '@xml:lang': 'x-default',
                    '#text': val
                }
            }
            await variatValues.push(attributeValues);
        });

        const data = {
            'variation-attribute-value': []
        }
        data['variation-attribute-value'] = variatValues;
        return data;
    }

    getVariantColors(mainProductId: any) {
        const colors = [] as any;
        const variations = mainProductId.split(";");
        const dataVariant = new Promise((resolve, reject) => {
            variations.map((variantId: any) => {
                return variation.filter((variationData: any) => {
                    if (variationData.ID === variantId) {
                        colors.push(variationData.c__color); resolve(colors);
                    }
                });
            });
        });

        return dataVariant.then(() => {
            return colors;
        });
    }

    getframeSizes(mainProductId: any) {
        const frameSizes = [] as any;
        const variations = mainProductId.split(";");
        const dataVariant = new Promise((resolve, reject) => {
            variations.map((variantId: any) => {
                return variation.filter((variationData: any) => {
                    if (variationData.ID === variantId) {
                        frameSizes.push(variationData.c__frameSize); resolve(frameSizes);
                    }
                });
            });
        });

        return dataVariant.then(() => {
            return frameSizes;
        });
    }

    getVariantImages(mainProductId: any) {
        const images = [] as any;
        const variations = mainProductId.split(";");
        const dataVariant = new Promise((resolve, reject) => {
            variations.map((variantId: any) => {
                return variation.filter((variationData: any) => {
                    if (variationData.ID === variantId && variationData.high_resolution_image !== '') {

                        const imageDetails = {
                            [variationData.c__color]: variationData.high_resolution_image.split(";"),
                            swatchImage: variationData.swatch_image

                        };

                        console.log("++++++++++++++++++++++++++++++++++++++++++++++++")
                        console.log(imageDetails)
                        console.log("+++++++++++++++++++++++++++++++++++++++++++++++++")
                        images.push(variationData.high_resolution_image); resolve(imageDetails);
                        
                    }
                });
            });
        });

        return dataVariant.then(() => {
            return images;
        });
    }

}

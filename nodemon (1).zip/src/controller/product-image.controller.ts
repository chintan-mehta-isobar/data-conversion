import { injectable } from "inversify";
import { Request, Response } from 'express';
const builder = require('xmlbuilder');
const firefoxImages = require('./json/firefox_variation_with_images.json');
@injectable()

export class ProductImageController {

    constructor() { }

    generateImageMapping(req: Request, res: Response) {
        let productData: any = [];
        firefoxImages.map((data: any) => {
            if (data.variants !== "") {
                const variants = data.variants.split(";");
                const productImageData = {
                    "@product-id": data.ID,
                    "images": this.mapProductImages(variants)
                }
                productData.push(productImageData);
                console.log(data.high_resolution_image);
            }
        });
        this.generateXML(productData);
    }

    private generateXML(productImageMapping: any) {
        const obj = {
            catalog: {
                '@xmlns': 'http://www.demandware.com/xml/impex/catalog/2006-10-31',
                '@catalog-id': 'firefox-master',
                product: productImageMapping
            }
        };
        const feed = builder.create(obj, { encoding: 'UTF-8' })
        return feed.end({ pretty: true });
    }


    mapProductImages(productVariantData: any) {
        productVariantData.map((variant: any) => {
            if (variant.high_resolution_image !== "") {
                let imageMapping = {
                    "image-group": {
                        "@view-type": "large",
                        "image": this.getImagePath(variant)
                    },
                }
            }
        });
        return Promise.resolve("aaa");
    }

    getImagePath(imagePath: any) {

    }

}
import { injectable } from "inversify";
import { Request, Response } from 'express';
const builder = require('xmlbuilder');
const storeLocator = require('./json/storelocator.json');
@injectable()

export class StoreLocatorController {

    constructor() { }

    generateStoreLocatorXml(req: Request, res: Response) {
        let store: any = [];
        storeLocator.map((data: any) => {
            if (data["store-id"] !== "" && data.latitude !== "" && data.longitude !== "") {
                let storeData = {
                    "@store-id": data["store-id"],
                    "name": data.name,
                    "address1": data.address1,
                    "city": data.city,
                    "postal-code": data["postal-code"],
                    "state-code": data["state-code"],
                    "country-code": data["country-code"],
                    "email": data.email,
                    "fax": "",
                    "store-events": "",
                    "store-hours": "",
                    "latitude": data.latitude,
                    "longitude": data.longitude,
                    "store-locator-enabled-flag": true,
                    "demandware-pos-enabled-flag": false,
                    "pos-enabled-flag": false,
                    "custom-attributes": {
                        "custom-attribute": [{
                            "@attribute-id": "countryCodeValue",
                            "#text": data["country-code"]
                        },{
                            "@attribute-id": "isFlagshipStore",
                            "#text": false
                        },{
                            "@attribute-id": "state-name",
                            "#text": data["state-name"]
                        }]
                    }
                };
                store.push(storeData);
            }
        });

        const obj = {
            stores: {
                '@xmlns': 'http://www.demandware.com/xml/impex/store/2007-04-30',
                store
            }
        };

        const feed = builder.create(obj, { encoding: 'UTF-8' }).end({ pretty: true })
        console.log(feed);
        return res.send(feed);
    }
}